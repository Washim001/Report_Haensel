#import some important libraries for further use
import warnings
warnings.filterwarnings('ignore')  #for ignore warnings
import numpy as np    #for doing scientific calculations
import pandas as pd   #for data anaylysis
from data import LoadData,PreProcessing  # load the data set
from sklearn.linear_model import LogisticRegression  #for train our model using LogisticRegression Classifier
import matplotlib.pyplot as plt #for plot the data
import seaborn as sns  #for plot the data
from model import *
from sklearn.metrics import classification_report
from sklearn.metrics import roc_curve, auc,accuracy_score
from sklearn.metrics import roc_auc_score,confusion_matrix
from sklearn.preprocessing import LabelBinarizer
from scipy import interp
from itertools import cycle
#import pandas_profiling
from sklearn.model_selection import cross_val_score,KFold
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
def plot_Roc(Y_test,Y_pred,algo):
	fpr = dict()
	tpr = dict()
	roc_auc = dict()
	n_classes=5
	lb = LabelBinarizer()
	lb.fit(Y_test)
	Y_test = lb.transform(Y_test)
	Y_pred = lb.transform(Y_pred)
	lw=2
	for i in range(n_classes):
		fpr[i], tpr[i], _ = roc_curve(Y_test[:, i], Y_pred[:, i])
		roc_auc[i] = auc(fpr[i], tpr[i])
	# Compute micro-average ROC curve and ROC area
	fpr["micro"], tpr["micro"], _ = roc_curve(Y_test.ravel(), Y_pred.ravel())
	roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])	
	# Compute macro-average ROC curve and ROC area
	# First aggregate all false positive rates
	all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
	# Then interpolate all ROC curves at this points
	mean_tpr = np.zeros_like(all_fpr)
	for i in range(n_classes):
		mean_tpr += interp(all_fpr, fpr[i], tpr[i])
	# Finally average it and compute AUC
	mean_tpr /= n_classes
	fpr["macro"] = all_fpr
	tpr["macro"] = mean_tpr
	roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
	# Plot all ROC curves
	plt.figure()
	plt.plot(fpr["micro"], tpr["micro"],
        label='micro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["micro"]),
         color='deeppink', linestyle=':', linewidth=4)
	plt.plot(fpr["macro"], tpr["macro"],
         label='macro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["macro"]),
         color='navy', linestyle=':', linewidth=4)
	colors = cycle(['aqua', 'darkorange', 'cornflowerblue'])
	noc=["A","B","C","D","E"]
	for i, color in zip(range(n_classes), colors):
		plt.plot(fpr[i], tpr[i], color=color, lw=lw,
             label='ROC curve of class {0} (area = {1:0.2f})'
             ''.format(noc[i], roc_auc[i]))
	plt.plot([0, 1], [0, 1], 'k--', lw=lw)
	plt.xlim([0.0, 1.0])
	plt.ylim([0.0, 1.05])
	plt.xlabel('False Positive Rate')
	plt.ylabel('True Positive Rate')
	plt.title('Some extension of ROC to multi-class for {}'.format(algo))
	plt.legend(loc="lower right")
	plt.draw()
def multiclass_roc_auc_score(y_test, y_pred, average="macro"):
	lb = LabelBinarizer()
	lb.fit(y_test)
	y_test = lb.transform(y_test)
	y_pred = lb.transform(y_pred)
	return roc_auc_score(y_test, y_pred, average=average)


#-------------------------------------------------------------------------------------------------------------------------------
#function for plot the countplot,boxplot,histplot
def basic_plot(data,i):
	fig,(ax1,ax2,ax3)=plt.subplots(nrows=1,ncols=3,figsize=(15,8))
	sns.countplot(x=data[i],data=data,ax=ax1)
	
	ax1.set_title('Countplot')
	sns.distplot(data[i],ax=ax2)
	ax2.set_title('distplot')
	sns.boxplot(x=data[i],data=data,ax=ax3,orient='v')
	ax3.set_title('boxplot')
	plt.show()
#Function For Calculate Accuracy

def model_per(Y_act,Y_pred):
	'''
	parameters:
	Y_act:-actual dependent variable
	Y_pred-:predicted dependent variable
	'''
	'''
	return:
	score:the accuracy of the model
	'''
	report=classification_report(Y_act,Y_pred)
	score=accuracy_score(Y_act,Y_pred)
	cm=confusion_matrix(Y_act,Y_pred)
	return report,score,cm



#-------------------------------------------------------------------------------------------------------------------------------
# function for geting basic info about data like "shape","first five rows","describe the data" 
def basic_statstical_info(dataset):
	dataframe=dataset.getDataFrame()  # get the dataframe
	X=dataset.get_X()  #get the input variables
	Y=dataset.get_Y() #get the dependent variables
	shape_dataframe=dataset.getShapeOfData()   #get the shape of dataframe
	shape_X=dataset.getShapeOfX()  # get the shape of input variable
	shape_Y=dataset.getShapeOfY()  #get the shape of dependent/traget variable
	print("first five rows of the dataframe:")
	print(dataframe.head())
	print("")
	print(" The shape of dataframe is :",shape_dataframe)
	print("")
	print(" The shape of input variable :",shape_X)
	print("")
	print(" The shape of target variable :",shape_Y)
	print("")
	print(" Get a concise summary of the dataframe")
	print(dataframe.info())
	print("")
	print(" Basic Statistical Information of Data ")
	print(dataframe.describe())
	print("")
	print("Number of Null Values in our dataset:-",dataframe.isnull().sum().sum())

#-------------------------------------------------------------------------------------------------------------------------------
print("Data Loading Start..........")
dataset=LoadData() #create an instance "dataset" of "LoadData" class 
print("Data Loading complete........")

X=dataset.get_X()
Y=dataset.get_Y()
#print(Y)
#pfrep=pandas_profiling.ProfileReport(dataframe)

#pfrep.to_file('profile_report1.html')
#print(pfrep)
basic_statstical_info(dataset)
print("Data preprocessing has beeen started...")	
pre_process=PreProcessing(X,Y)#create an instance "pre_process" of "PreProcessing" class
Y=pre_process.give_label()     #give label to categorized data
X_train,X_test,Y_train,Y_test=pre_process.split_in_train_test()#split the data
X_train,X_test=pre_process.normalization_of_data()#normalize the data
print("Data PreProcessing has been completed...")
#--------------------------------------------------------------------------------------------------------------------------------
#create model for predication
print("LogisticRegression:--")
Y_pred=logistic_regression(X_train,X_test,Y_train)
k_fold = KFold(len(Y), random_state=0)
clf = LogisticRegression()
scores=cross_val_score(clf, X, Y,cv=10)
print("\n\nAcuracy using 10 fold validation %.2f\n\n"%(scores.mean()*100))
dataframe=dataset.getDataFrame()

print("Model Performance:-")
model_performance,accuracy,cm=model_per(Y_test,Y_pred)
print("Here is your model Performance:-")
print(model_performance)
print("Accuracy is %f"%(accuracy*100))
print("Confusion Matrix")
print(cm)
x=multiclass_roc_auc_score(Y_test,Y_pred)
print("ROC AUC Score:-",x)
plot_Roc(Y_test,Y_pred,"Logistic Regression")
print("\n\n -------------------------------------------------------------------------------\n\n")
print("Decission tree:-")
Y_pred=decission_tree(X_train,X_test,Y_train)
k_fold = KFold(len(Y), random_state=0)
clf = DecisionTreeClassifier()
scores=cross_val_score(clf, X, Y,cv=10)
print("\n\nAcuracy using 10 fold validation %.2f\n\n"%(scores.mean()*100))
dataframe=dataset.getDataFrame()

print("Model Performance:-")
model_performance,accuracy,cm=model_per(Y_test,Y_pred)
print("Here is your model Performance:-")
print(model_performance)
print("Accuracy is %f"%(accuracy*100))
print("Confusion Matrix")
print(cm)
x=multiclass_roc_auc_score(Y_test,Y_pred)
print("ROC AUC Score:-",x)
plot_Roc(Y_test,Y_pred,"Decission tree")
print("\n\n------------------------------------------------------------------------------\n\n")
print("Random Forest")
Y_pred=random_forest(X_train,X_test,Y_train)
k_fold = KFold(len(Y), random_state=0)
clf = RandomForestClassifier()
scores=cross_val_score(clf, X, Y,cv=10)
print("\n\nAcuracy using 10 fold validation %.2f\n\n"%(scores.mean()*100))
dataframe=dataset.getDataFrame()

print("Model Performance:-")
model_performance,accuracy,cm=model_per(Y_test,Y_pred)
print("Here is your model Performance:-")
print(model_performance)
print("Accuracy is %f"%(accuracy*100))
print("Confusion Matrix")
print(cm)
x=multiclass_roc_auc_score(Y_test,Y_pred)
print("ROC AUC Score:-",x)
plot_Roc(Y_test,Y_pred,"Random Forest")
plt.show()
print("\n\n------------------------------------------------------------------------------\n\n")
print("Support Vector Machine")
Y_pred=svm(X_train,X_test,Y_train)
k_fold = KFold(len(Y), random_state=0)
clf = SVC()
scores=cross_val_score(clf, X, Y,cv=10)
print("Acuracy using 10 fold validation %.2f"%(scores.mean()))
dataframe=dataset.getDataFrame()

print("Model Performance:-")
model_performance,accuracy,cm=model_per(Y_test,Y_pred)
print("Here is your model Performance:-")
print(model_performance)
print("Accuracy is %f"%(accuracy*100))
print("Confusion Matrix")
print(cm)
x=multiclass_roc_auc_score(Y_test,Y_pred)
print("ROC AUC Score:-",x)
plot_Roc(Y_test,Y_pred,"svm")

'''print("Plotting......")
ls=[3,4,23,36,43,64,294]
basic_plot(dataframe,ls[0])
print("Thank You ")
'''
