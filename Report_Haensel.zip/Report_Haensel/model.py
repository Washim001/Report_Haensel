#import some important libraries for further use
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
def logistic_regression(X_train,X_test,Y_train):
	classifier=LogisticRegression()     #create an object "classifier" of LogisticRegression class
	classifier.fit(X_train,Y_train)     #fit the data on training set means train our model
	Y_pred=classifier.predict(X_test)   #calculate prediction on test data
	return Y_pred

def knn(X_train,X_test,Y_train):
	classifier=KNeighborsClassifier(n_neighbors=5,metric='minkowski',p=2)
	classifier.fit(X_train,Y_train)
	Y_pred=classifier.predict(X_test)
	return Y_pred

def svm(X_train,X_test,Y_train):
	classifier=SVC(kernel='linear',random_state=0)
	classifier.fit(X_train,Y_train)
	Y_pred=classifier.predict(X_test)
	return Y_pred



def naive(X_train,X_test,Y_train):
	classifier=GaussianNB()
	classifier.fit(X_train,Y_train)
	Y_pred=classifier.predict(X_test)
	return Y_pred

def decission_tree(X_train,X_test,Y_train):
	classifier=DecisionTreeClassifier(criterion='entropy',random_state=0)
	classifier.fit(X_train,Y_train)
	Y_pred=classifier.predict(X_test)
	return Y_pred
def random_forest(X_train,X_test,Y_train):
	classifier=RandomForestClassifier(n_estimators=10,criterion='entropy',random_state=0)
	classifier.fit(X_train,Y_train)
	Y_pred=classifier.predict(X_test)
	return Y_pred