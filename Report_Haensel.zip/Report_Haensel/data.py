#import some important libraries for further use
import warnings
warnings.filterwarnings('ignore')  #for ignore warnings

import numpy as np    #for doing scientific calculations
import pandas as pd   #for data anaylysis
from sklearn.model_selection import train_test_split # For split the data into training and test data
from sklearn.preprocessing import StandardScaler # For Normalize the data means zero mean and one standard deviation
from sklearn.preprocessing import LabelEncoder # for give label to categorized data
#----------------------------------------------------------------------------------------------------------------------
# --- class for load the data ---
class LoadData:
	def __init__(self): 
		self.data=pd.read_csv('sample.csv',header=None)
		self.data.drop([59,179,268,269,270,271,272,273,274,275,276],axis=1,inplace=True)
		self.X=self.data.iloc[:,:-1].values
		self.Y=self.data.iloc[:,self.data.shape[1]-1].values
	def getDataFrame(self): #function for geting dataframe
		return self.data
	def get_X(self):      #function for geting input features
		return self.X
	def get_Y(self):      #function for geting dependent variable
		return self.Y
	def getShapeOfData(self):   #for geting the shape of our dataframe
		return self.data.shape
	def getShapeOfX(self):     #for geting the shape of input features
		return self.X.shape
	def getShapeOfY(self):  #for geting the shape of dependent variable
		return self.Y.shape
#------------------------------------------------------------------------------------------------------------------
# --- Class For Preprocess the data ---
class PreProcessing:
	def __init__(self,X,Y):
		self.X=X
		self.Y=Y
		self.X_train=None
		self.X_test=None
		self.Y_train=None
		self.Y_test=None
	def split_in_train_test(self):  #function for split the data into training set and testset
		self.X_train,self.X_test,self.Y_train,self.Y_test=train_test_split(self.X,self.Y,test_size=0.1,random_state=0)
		return self.X_train,self.X_test,self.Y_train,self.Y_test
	def normalization_of_data(self): # function for normalized the data
		sc_X=StandardScaler()   #create an object "sc_X" of "StandardScaler" class
		self.X_train=sc_X.fit_transform(self.X_train) #fit and transform training input variable on sc_X
		self.X_test=sc_X.transform(self.X_test)  # transform test input variable on sc_X
		return self.X_train,self.X_test
	def give_label(self):#function for give the label to categorized data
		labelencoder=LabelEncoder() #create an object "labelencoder" of "LabelEncoder" class
		self.Y=labelencoder.fit_transform(self.Y)# fit and transform the output/dependent variable
		return self.Y
		



